<?php
/** This translation belongs to the Module Workflow2 and must not used without this module **/
require('Settings/Workflow2.php');
