<?php
/**
 This File was developed by Stefan Warnat <vtiger@stefanwarnat.de>

 It belongs to the Workflow Designer and must not be distributed without complete extension
 * @version 1.2
 * @updated 2013-06-23
**/
if(!class_exists("VtUtils")) {

class VtUtils extends Workflow\VtUtils
{

}
}

?>