<?php return array (
  'image' => 
  array (
    'inventoryField' => 'image',
    'label' => 'image',
    'implemented' => false,
  ),
  'purchase_cost' => 
  array (
    'inventoryField' => 'purchase_cost',
    'label' => 'purchase_cost',
    'implemented' => false,
  ),
  'margin' => 
  array (
    'inventoryField' => 'margin',
    'label' => 'margin',
    'implemented' => false,
  ),
);