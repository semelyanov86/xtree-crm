<?php
/**
 * @package WorkflowDesigner
 */

function getFolderId($folder, $connectionID) {
    \Workflow2\Autoload::register("CloudFile", "~/modules/CloudFile/lib");

    $adapter = \CloudFile\Connection::getAdapter($connectionID);

    $adapter->chdir($folder);
    return $adapter->getCurrentPathKey();
}