<?php

namespace Workflow\Plugins\ConnectionProvider;

class MatrixOrg extends \Workflow\ConnectionProvider{

    protected $_title = 'Matrix.org Server';

    protected $OAuthEnabled = false;

    private function request($method = "GET", $endpoint, $params = array()) {

        $response = \Workflow\VtUtils::getContentFromUrl(
            $this->getEndpoint() . $endpoint,
            json_encode($params),
            $method,
            array(
                // 'debug' => true,
                'auth' => array(
                    'bearer' => $this->get('access_token'),
                ),
                'headers' => array(
                    'Content-Type: application/json'
                )
            )
        );

        if(!empty($response['errcode'])) {
            throw new \Exception($response['error']);
        }


        return $response;
    }

    public function test() {
        $this->request('GET', 'capabilities');
    }

    public function getConfigFields()
    {
        return array_merge($this->configFields, array(
            'server' => array(
                'label' => 'Matrix server URL',
                'type' => 'text',
                'description' => 'Ask your Matrix administrator for this URL. Often it is different to the URL to use Web Client',
            ),
            'access_token' => array(
                'label' => 'Access token for user',
                'type' => 'text',
                'description' => 'You get in your user settings -> About -> show Access Token',

            ),
        ));
    }

    public function getEndpoint() {
        $url = trim($this->get('server'), '/') . '/_matrix/client/r0/';

        return $url;
    }

    public function sendMessage($room_id, $text){

        $params = array(
            'msgtype' => 'm.text',
            'body' => $text
        );

        $response = $this->request('POST',"rooms/" . $room_id . "/send/m.room.message", $params);

        return $response;
    }
}

\Workflow\ConnectionProvider::register('matrix', '\Workflow\Plugins\ConnectionProvider\MatrixOrg');