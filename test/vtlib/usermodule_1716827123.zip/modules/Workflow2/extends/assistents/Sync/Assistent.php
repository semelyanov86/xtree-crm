<?php

namespace Workflow\Plugins\Assistents;

class Sync extends \Workflow\AssistentBase {
    protected $Name = 'Sync two fields';
    protected $Description = 'This assistent assist you to create a Workflow to sync a fieldvalue from one record to another';

}