<?php
/* DEPRECATED */
if(!class_exists("VTWfExpressionParser")) {

class VTWfExpressionParser extends Workflow\ExpressionParser
{

}

}

?>