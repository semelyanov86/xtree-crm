<?php
/**
Not used anymore
 * Please replace with Workflow_Task Workflow_Task
 **/
abstract class WfTask extends Workflow_Task { }

?>