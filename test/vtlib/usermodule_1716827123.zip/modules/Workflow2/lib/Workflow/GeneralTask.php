<?php
/**
 * Created by PhpStorm.
 * User: Stefan
 * Date: 01.07.2016
 * Time: 00:10
 */

namespace Workflow;


class GeneralTask extends Task
{
    public function handleTask(&$context) {

    }
}