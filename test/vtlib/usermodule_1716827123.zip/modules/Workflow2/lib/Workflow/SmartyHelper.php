<?php
/**
 * Created by PhpStorm.
 * User: Stefan
 * Date: 16.11.2016
 * Time: 17:56
 */

namespace Workflow;

class SmartyHelper
{
    //public function getFields
}