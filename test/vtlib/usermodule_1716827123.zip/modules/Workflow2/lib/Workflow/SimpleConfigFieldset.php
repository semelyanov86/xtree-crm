<?php
/**
 * Created by PhpStorm.
 * User: Stefan
 * Date: 26.10.2016
 * Time: 18:39
 */

namespace Workflow;

use Workflow\Preset\SimpleConfig;

class SimpleConfigFieldset extends SimpleConfig
{

}