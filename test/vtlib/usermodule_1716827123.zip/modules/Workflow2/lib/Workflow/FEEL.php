<?php

namespace Workflow;

// Implements
// https://docs.camunda.org/manual/7.4/reference/dmn11/feel/language-elements/


class FEEL
{
    public function compare($sourceValue, $checkValue) {

    }
}