<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Stefan Warnat <support@stefanwarnat.de>
 * Date: 12.04.14 18:28
 * You must not use this file without permission.
 */
namespace Workflow;

// Deprecated: User Execution Logger instead
class ConditionLogger extends ExecutionLogger { }
