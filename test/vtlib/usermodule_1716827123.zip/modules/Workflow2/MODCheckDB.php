<?php
require_once('Workflow2.php');
(new \Workflow2())->checkDB();

