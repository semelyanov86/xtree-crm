<?php
/* deprecated since vt6 */

?>