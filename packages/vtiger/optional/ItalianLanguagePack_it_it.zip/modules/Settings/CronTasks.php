<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/
$languageStrings = array(
	'CronTasks'                    => 'Programmazione'                   , // TODO: Review
	'Id'                           => 'Id'                          , // TODO: Review
	'Cron Job'                     => 'Cron Job'                    , // TODO: Review
	'Frequency'                    => 'Frequenza'                   , // TODO: Review
	'Status'                       => 'Stato'                      , // TODO: Review
	'Last Start'                   => 'L\'ultima scansione avviata'           , // TODO: Review
	'Last End'                     => 'L\'ultima scansione finita'             , // TODO: Review
	'Sequence'                     => 'Sequenza'                    , // TODO: Review
	'LBL_COMPLETED'                => 'Completato'                   , // TODO: Review
	'LBL_RUNNING'                  => 'In corso'                     , // TODO: Review
	'LBL_ACTIVE'                   => 'Attivo'                      , // TODO: Review
	'LBL_INACTIVE'                 => 'Non attivo'                   , // TODO: Review
);