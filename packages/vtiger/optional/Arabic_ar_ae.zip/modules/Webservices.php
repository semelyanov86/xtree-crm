<?php
/*********************************************************************************
 ** The contents of this file are subject to the vtiger CRM Public License Version 1.0
  * ("License"); You may not use this file except in compliance with the License
  * The Original Code is: vtiger CRM Open Source
  * The Initial Developer of the Original Code is vtiger.
  * Portions created by vtiger are Copyright (C) vtiger.
  * All Rights Reserved.
 *
  ********************************************************************************/

$languageStrings = array(
	'LBL_INVALID_OLD_PASSWORD' => 'قيمة غير صالحة نظرا لكلمة المرور القديمة.',
	'LBL_NEW_PASSWORD_MISMATCH' => "كلمة المرور الجديدة وتأكيد كلمة المرور غير متطابقين",
	'LBL_DATABASE_QUERY_ERROR' => 'خطأ في قاعدة البيانات أثناء تنفيذ العملية المطلوبة',
	'LBL_CHANGE_PASSWORD_FAILURE' => 'فشل في تغيير كلمة المرور',
);




